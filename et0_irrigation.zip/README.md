# ET₀ Irrigation — Custom Component for Home Assistant

Calcula a evapotranspiração de referência (ET₀) pelo método **Penman-Monteith FAO-56**
e expõe sensores de **déficit hídrico** para uso em automações de irrigação inteligente.

## Sensores criados

| Entidade | Descrição |
|---|---|
| `sensor.et0_irrigation_et0_today` | ET₀ acumulada do dia atual (mm) |
| `sensor.et0_irrigation_deficit_1d` | Déficit hídrico último 1 dia (mm) |
| `sensor.et0_irrigation_deficit_2d` | Déficit hídrico últimos 2 dias (mm) |
| `sensor.et0_irrigation_deficit_3d` | Déficit hídrico últimos 3 dias (mm) |
| `sensor.et0_irrigation_deficit_4d` | Déficit hídrico últimos 4 dias (mm) |
| `sensor.et0_irrigation_deficit_5d` | Déficit hídrico últimos 5 dias (mm) |

Déficit positivo = solo com falta de água → irrigar.
Déficit negativo = solo com excesso → não irrigar.

## Instalação

1. Copie a pasta `et0_irrigation` para `config/custom_components/`
2. Reinicie o Home Assistant
3. Vá em **Configurações → Dispositivos e Serviços → Adicionar Integração**
4. Pesquise por **ET₀ Irrigation** e configure os sensores

## Sensores necessários na estação

| Parâmetro | Unidades suportadas |
|---|---|
| Temperatura | °C |
| Umidade relativa | % |
| Velocidade do vento | km/h ou m/s |
| Luminosidade | lux |
| Pressão atmosférica | hPa ou kPa |
| Chuva acumulada do dia | mm |

## Uso na automação de irrigação

### Zonas e grupos de irrigação

- **Zona de irrigação**: uma válvula/switch individual.
- **Grupo de irrigação**: conjunto de zonas de irrigação que ligam **simultaneamente**.

Ao iniciar um grupo, todas as zonas do grupo são ligadas juntas. Cada zona é desligada no seu tempo calculado/definido.

Substitua todas as condições de chuva por uma única condição de déficit:

```yaml
alias: Irrigação jardim
triggers:
  - trigger: time
    at: "02:00:00"
conditions:
  - condition: state
    entity_id: input_boolean.irrigacao_automatica
    state: "on"
  - condition: numeric_state
    entity_id: sensor.et0_irrigation_deficit_5d
    above: 8        # mm — ajuste conforme seu jardim
actions:
  - choose:
      # ... suas sequências de zona por dia da semana
```

### Sugestão de thresholds iniciais

| Sensor de déficit | Threshold sugerido | Quando usar |
|---|---|---|
| `deficit_1d` | > 3 mm | Plantas muito sensíveis |
| `deficit_3d` | > 6 mm | Jardim geral |
| `deficit_5d` | > 8 mm | Solo com boa retenção hídrica |

Ajuste os valores após observar o comportamento por 2–3 semanas.

## Atributos extras

Cada sensor de déficit expõe `daily_detail` com o balanço diário:

```json
[
  { "date": "2026-03-24", "et0_mm": 5.21, "rain_mm": 0.0,  "deficit_mm": 5.21 },
  { "date": "2026-03-25", "et0_mm": 4.87, "rain_mm": 12.4, "deficit_mm": -7.53 }
]
```

Útil para dashboard e depuração.

## Detalhes do método

- **Fórmula:** Penman-Monteith FAO-56 (Allen et al., 1998)
- **Irradiação solar:** integração trapezoidal do sensor de luminosidade (lux → W/m² ÷ 120)
- **Constante psicrométrica:** calculada com a pressão atmosférica medida em tempo real
- **Fluxo de calor do solo (G):** zero (adequado para timestep diário)
- **Radiação líquida de ondas longas:** usa temperatura média (simplificação sem Tmax/Tmin)
- **Histórico:** consultado via `recorder` — não requer helpers auxiliares
